<?php
  define('URL', "http:/localhost");
  //define('URL', 'http://lucasvangastel.com/');
?>
