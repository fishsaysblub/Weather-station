<?php
	require('config.php');

	require('includes/header.php');

	if (file_exists('pages/' . $page . ".php"))
	{
		include('pages/' . $page . '.php');
	}
	else
	{
		include('pages/404.shtml');
	}

	require('includes/footer.php');
?>
